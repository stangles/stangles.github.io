package com.angles;

import org.springframework.stereotype.Service;
import pl.allegro.finance.tradukisto.ValueConverters;

import java.util.Optional;

@Service
class NumberConverterService {

    private static final int MIN_LIMIT_INCLUSIVE = 0;
    private static final int MAX_LIMIT_INCLUSIVE = 10000;

    Optional<String> convertToEnglish(int number) {
        if (number < MIN_LIMIT_INCLUSIVE || number > MAX_LIMIT_INCLUSIVE) {
            return Optional.empty();
        }

        final ValueConverters converter = ValueConverters.ENGLISH_INTEGER;
        final StringBuilder inEnglish = new StringBuilder(converter.asWords(number));

        // capitalize first letter
        inEnglish.setCharAt(0, Character.toUpperCase(inEnglish.charAt(0)));

        insertAndBeforeTens(inEnglish);

        // replace all instances of '-' with a space
        return Optional.of(inEnglish.toString().replaceAll("-", " "));
    }

    /**
     * Assuming the maximum number parsed to English is 10,000,
     * this method inserts "and" before the tens place in the English
     * representation of the number. Behavior is undefined for any
     * English representation of a number less than 0 or greater than 10000.
     *
     * @param builder a StringBuilder representing the English equivalent of a number
     */
    private static void insertAndBeforeTens(final StringBuilder builder) {
        int hundredPos = builder.lastIndexOf("hundred");
        int thousandPos = builder.lastIndexOf("thousand");

        if (hundredPos > thousandPos) {
            if (hundredPos < (builder.length() - "hundred".length())) {
                builder.insert(hundredPos + "hundred".length(), " and");
            }
        } else if (thousandPos > hundredPos) {
            if (thousandPos < (builder.length() - "thousand".length())) {
                builder.insert(thousandPos + "thousand".length(), " and");
            }
        }
    }
}
