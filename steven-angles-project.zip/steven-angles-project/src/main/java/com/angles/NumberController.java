package com.angles;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.Optional;

@RestController
class NumberController {

    private NumberConverterService numberConverterService;

    @Autowired
    NumberController(NumberConverterService numberConverterService) {
        this.numberConverterService = numberConverterService;
    }

    @ResponseBody
    @RequestMapping("/number/{number}/english")
    String getNumberInEnglish(@PathVariable("number") int number, HttpServletResponse response) {
        Optional<String> inEnglish = numberConverterService.convertToEnglish(number);

        if (inEnglish.isPresent()) {
            return inEnglish.get();
        } else {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            return "";
        }
    }
}
