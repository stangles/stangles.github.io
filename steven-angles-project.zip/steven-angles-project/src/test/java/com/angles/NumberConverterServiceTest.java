package com.angles;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static junit.framework.TestCase.assertFalse;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class NumberConverterServiceTest {

    private NumberConverterService underTest;

    @Before
    public void setup() {
        underTest = new NumberConverterService();
    }

    @Test
    public void testConvertNumberBelowZero() {
        assertFalse(underTest.convertToEnglish(-1).isPresent());
    }

    @Test
    public void testConvertNumberAboveTenThousand() {
        assertFalse(underTest.convertToEnglish(10001).isPresent());
    }

    @Test
    public void testEdgeCases() {
        assertThat(underTest.convertToEnglish(0).get(), is("Zero"));

        assertThat(underTest.convertToEnglish(10000).get(), is("Ten thousand"));
    }

    @Test
    public void testStandardCases() {
        assertThat(underTest.convertToEnglish(13).get(), is("Thirteen"));

        assertThat(underTest.convertToEnglish(85).get(), is("Eighty five"));

        assertThat(underTest.convertToEnglish(5237).get(), is("Five thousand two hundred and thirty seven"));

        assertThat(underTest.convertToEnglish(1900).get(), is("One thousand nine hundred"));

        assertThat(underTest.convertToEnglish(2004).get(), is("Two thousand and four"));

        assertThat(underTest.convertToEnglish(102).get(), is("One hundred and two"));

        assertThat(underTest.convertToEnglish(127).get(), is("One hundred and twenty seven"));
    }
}
