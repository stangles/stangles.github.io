package com.angles;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletResponse;

import javax.servlet.http.HttpServletResponse;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class NumberControllerTest {

    @Mock
    private NumberConverterService numberConverterService;

    private NumberController underTest;

    private MockHttpServletResponse servletResponse;

    @Before
    public void setup() {
        underTest = new NumberController(numberConverterService);
        servletResponse = new MockHttpServletResponse();

        Mockito.when(numberConverterService.convertToEnglish(42)).thenReturn(Optional.of("Forty two"));
        Mockito.when(numberConverterService.convertToEnglish(-1)).thenReturn(Optional.empty());
    }

    @Test
    public void testNumberInRange() {
        assertEquals("Forty two", underTest.getNumberInEnglish(42, servletResponse));
        assertEquals(HttpServletResponse.SC_OK, servletResponse.getStatus());
    }

    @Test
    public void testNumberOutOfRange() {
        String response = underTest.getNumberInEnglish(-1, servletResponse);

        assertTrue(response.isEmpty());
        assertEquals(HttpServletResponse.SC_NOT_FOUND, servletResponse.getStatus());
    }
}
