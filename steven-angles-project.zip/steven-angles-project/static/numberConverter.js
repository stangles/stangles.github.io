var app = new Vue({
  el: '#app',
  data: {
    number: '',
    english: ''
  },
  methods: {
    convert: function (event) {
      if (this.isValid) {
        this.$http.get('http://localhost:8080/number/' + this.number + '/english').then((response) => {
          response.text().then((data) => {
            this.english = this.number + ": " + data;
            this.number = '';
          })
        }, (response) => {
          if (response.status === 404) {
            // english equivalent not found
            this.english = 'Please enter a number between 0 and 10000 inclusive'
          } else {
            this.english = 'There was an issue converting your number, try again later'
          }
        });
      }
    }
  },
  // validations from here: https://vuejs.org/examples/firebase.html
  computed: {
    validation: function () {
      var num = this.number.trim();
      return {
        isEmpty: !!num,
        isNumber: Number.isInteger(Number(num)) && num >= 0 && num <= 10000
      }
    },
    isValid: function () {
      var validation = this.validation;
      return Object.keys(validation).every(function (key) {
        return validation[key]
      });
    }
  }
});
