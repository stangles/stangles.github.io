# Number Converter

# Running the project
Running the project is simple, just execute:

`java -jar /path/to/project/root/stangles-0.0.1-SNAPSHOT.jar`

# Using the app
Navigate to [localhost:8080](http://localhost:8080)

From there, you can convert numbers by entering numbers in the text box and pressing "Convert Number"

# Testing
The Spring boot app has unit and integration tests which provide 100% test coverage for `NumberConverterService.java` and `NumberController.java`

You can run these tests by running `mvn test` in the root directory of the project. Alternatively, you can run `./mvnw test` if you do not have maven.

# Technologies
- Back end
    - Java 8
    - Spring boot
    - Maven
    - JUnit
    - Mockito
    - [Tradukisto](https://github.com/allegro/tradukisto)
    
- Front end
    - [vue.js](https://vuejs.org/)
    
I chose the technologies on the back end because I was familiar with them and could put something together quickly. Additionally, I opted to use a library for converting the numbers.
The reason for this is because the library is well written, maintained and tested (100% coverage). It is also published to the maven central repo so it is easy to manage as a dependency.
While I did have to tweak the library's output to fit the requirements, I believe it was less work for me to accomplish the task than if I had not used the library. Overall, the library
made it easier for me to test my code and accomplish my goal.

For the front end, I chose vue.js because I had never used it before and I wanted to challenge myself to use something different. I do not consider myself a strong front-end developer,
but I had read that vue.js is easy to pick up and get started with, no matter your skill level. I would agree with that assessment. If I wanted to make a more production-ready front-end
component, I would extract the vue instance methods into a component and test them with karma/jasmine. Additionally, I would write some full end-to-end tests rather than running them
myself.